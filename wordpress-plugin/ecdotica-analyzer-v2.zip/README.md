# Ecdotica AI Assistant - Plugin WordPress

Plugin de WordPress que integra la API de Ecdotica para asistencia editorial con IA.

## Instalación

1. Clonar el repositorio en `wp-content/plugins/`
2. Activar el plugin desde el panel de WordPress
3. Configurar la URL de la API en el archivo principal

## Uso

El plugin agrega un panel lateral en el editor de Gutenberg con tres funciones:
- Análisis de texto
- Sugerencias editoriales
- Registro en blockchain

Ver documentación completa en el repositorio.
